<template>
  <div
    class="container"
    :class="{ fullscreen: fullscreen }"
  >
    <div class="spinner">
      <div class="double-bounce1" />
      <div class="double-bounce2" />
    </div>
  </div>
</template>

<script src="./ft-loader.js" />
<style scoped src="./ft-loader.css" />
