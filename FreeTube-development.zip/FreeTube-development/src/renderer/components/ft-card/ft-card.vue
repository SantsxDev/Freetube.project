<template>
  <div
    class="ft-card"
  >
    <slot />
  </div>
</template>

<script src="./ft-card.js" />
<style scoped src="./ft-card.css" />
